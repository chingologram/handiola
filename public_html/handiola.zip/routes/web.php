<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@inicio')->name('/');
Route::get('login', 'HomeController@login')->name('login');
Route::get('calcularReserva', 'HomeController@calcularReserva')->name('calcularReserva');
Route::get('contacto', 'HomeController@contacto')->name('contacto');

Route::post('logininit','Auth\LoginController@login')->name('logininit');
Route::get('logout','Auth\LoginController@logout')->name('logout');
Route::get('redirectgo', 'Auth\LoginController@redirectToProvider');
Route::get('logdas', 'Auth\LoginController@handleProviderCallback');
//callbackFacebook
Route::get('facebook', 'facecontroller@redirectToProvider');
Route::get('callbackFacebook', 'facecontroller@handleProviderCallback');
