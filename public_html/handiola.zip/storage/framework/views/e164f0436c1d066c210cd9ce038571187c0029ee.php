<?php $__env->startSection('wrapper'); ?>
<div class="site-index">

  <section id="banner">
       <div class="inner">
           <img src="template/images/br.png" alt="">
         <p><a href="http://templated.co">Tenés tu departamento en alquiler temporario o Airbnb en Buenos Aires, ¿Querés aumentar tus ingresos sin ocuparte de las gestiones?</a></p>
         <ul class="actions">
           <li><a href="login" class="button big special">Iniciar Sesión</a></li>
           <li><a href="calcularReserva" class="button big alt">Reserva Ya!</a></li>
         </ul>
       </div>
     </section>

    <div class="body-content">

      <section id="one" class="wrapper style1">
     				<header class="major">
     					<h2>Handiola</h2><br>
     					<p>Conoce Nuestros Beneficios</p>
     				</header>
     				<div class="container">
     					<div class="row">
     						<div class="3u">
     							<section class="special box">
     								<i class="icon"><img src="template/images/Tiempo.png" width='100px' alt=""></i><br>
     								<h3>Ahorrá tiempo</h3><br><br>
     								<p>Obtené las mejores evaluaciones.</p><p> Nuestra experiencia en la industria te hará el mejor host.</p>
     							</section>
     						</div>
     						<div class="3u">
     							<section class="special box">
     								<i class="icon"><img src="template/images/Gestiones.png" width='100px' alt=""></i>
     								<h3>Olvidate de las gestiones</h3>
     								<p>Recibiremos y despediremos cálidamente a tus huéspedes. Check In/out flexibles. Dejá limpieza, blanquería y lavandería en nuestras manos. Hacemos chequeos de seguridad antes y después de cada reserva.</p>
     							</section>
     						</div>
     						<div class="3u">
     							<section class="special box">
     								<i class="icon"><img src="template/images/Seguridad.png" width='100px' alt=""></i>
     								<h3>La seguridad primero</h3>
     								<p>Sólo quienes hayan pasado nuestro duro proceso de reclutamiento pueden formar parte de Handiola. Sabemos que contás con nosotros. Te garantizamos que siempre vamos a cumplirte. Mantenemos altos estándares de seguridad y protección.</p>
     							</section>
     						</div>



     						<div class="3u">
     							<section class="special box">
     								<i class="icon"><img src="template/images/Host.png" width='100px' alt=""></i>
     								<h3>Aumentá tus ingresos y sé el mejor anfitrión</h3>
     								<p>Obtené las mejores evaluaciones. Nuestra experiencia en la industria te hará el mejor host.</p>
     							</section>
     						</div>
     					</div>
     				</div>
     			</section>

     		<!-- Two -->
     			<section id="two" class="wrapper style2">
     				<header class="major">
     					<h2>Conocenos!</h2><br>
     					<p>¿Quienes estan detras de Handiola?</p>
     				</header>
     				<div class="container">
     					<div class="row">
     						<div class="4u">
     							<section class="special">
     								<a href="#" class="image fit"><img src="template/images/juan.png" alt=""></a>
     								<h3>Juan Pablo Herrera</h3>
     								<p>Juanpa crea Handiola para poner a disposición de los anfitriones toda su expertise de más de 10 años en operación de hoteles. Le gusta conectar personas. Ahora está basado en Buenos Aires y quiere que los turistas se sientan en casa y que adoren la ciudad tanto como él lo hace.</p>
     								<ul class="actions">

     								</ul>
     							</section>
     						</div>
     						<div class="4u">
     							<section class="special">
     								<a href="#" class="image fit"><img src="template/images/majo.png" alt=""></a>
     								<h3>María José Ovalles</h3>
     								<p>Majo, viene a crear la estrategia de marca. Ama que el turismo actual sea sumergirse en la experiencia local y formar parte de ella. Los anfitriones son quienes lo hacen posible y para ella la verdadera acción creativa de Handiola está en lograr que los usuarios lleguen a ser eso que desean ser.</p>
     								<ul class="actions">

     								</ul>
     							</section>
     						</div>
     						<div class="4u">
     							<section class="special">

     								<a href="#" class="image fit"><img src="template/images/dan.png" alt=""></a>
     								<h3>Daniel Figueroa</h3>
     								<p>Es el genio detrás de Handiola. Ingeniero en Telecomunicaciones, orientado a la comunicación y a la seguridad virtual. Dani ha desarrollado productos y apps para empresas globales. Enfoca su energía en humanizar esa tecnología con el fin de tener más tiempo para la música y las risas en el mundo real.</p>
     								<ul class="actions">

     								</ul>
     							</section>
     						</div>
     					</div>
     				</div>
     			</section>
          <section id="three" class="wrapper style1">
            <div class="container">
                <div class="row">
                 <div class="6u">
                   <label for="">Llamanos: 11-61860830</label>
                 </div>
                 <div class="6u">
                  <label for="">Te escribimos:</label>
                    <input type="text" name="" value=""><br>
                    <button type="button" name="button" class="button special" id="enviar">Enviar</button>
                  </div>
                 </div>
              </div>
             </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<style>
  #skel-layers-hiddenWrapper{
    width: 0%;
    height: 0%;
    display: none;
  }

</style>

<?php echo $__env->make('Layouts/_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>