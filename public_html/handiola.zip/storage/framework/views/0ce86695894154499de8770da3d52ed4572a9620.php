<html>
	<head>
		<title>Handiola</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="template/js/jquery.min.js"></script>
		<script src="template/js/skel.min.js"></script>
		<script src="template/js/skel-layers.min.js"></script>
		<script src="template/js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="template/css/skel.css" />
			<link rel="stylesheet" href="template/css/style.css" />
			<link rel="stylesheet" href="template/css/style-xlarge.css" />
		</noscript>

    
	</head>
	<body id="top">
    <header id="header" class="skel-layers-fixed">
        <img src="template/images/finalbrand.png" alt="">
        <nav id="nav">
          <ul>
            <li><a class="nav-link" href="/">Inicio</a></li>
            <li></a><a class="nav-link" href="contacto">Contacto</a></li>
            <?php if(Auth::check()): ?>
            <li class="nav-item">
              <a class="nav-link" href="servicios">Reservas</a>
            </li>
            <li class="nav-item">
              <a href="logout" class="button special">Cerrar Sesión</a>
            </li>
            <?php else: ?>
            <li class="nav-item">
              <a href="login" class="button special">Iniciar Sesión</a>
            </li>
           <?php endif; ?>
          </ul>
        </nav>
      </header>
      <div>
         <?php echo $__env->yieldContent('wrapper'); ?>
      </div>
      <footer id="footer">
          <div class="container">
            <div class="row double">
              <div class="6u">

              </div>
              <div class="6u">
                <h2>Handiola</h2>
                <p>No te olvides de darle un vistazo a nuestras Redes Sociales, y asi estaras al tanto de nuestras ultimas novedades.</p>
                <ul class="icons">
                  <li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
                  <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
                  <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
                  <li><a href="#" class="icon fa-linkedin"><span class="label">LinkedIn</span></a></li>
                  <li><a href="#" class="icon fa-pinterest"><span class="label">Pinterest</span></a></li>
                </ul>
              </div>
            </div>
            <ul class="copyright">
              <li>&copy; Handiola. Todos los Derechos Reservados.</li>

            </ul>
          </div>
        </footer>
        <style media="screen">
          #skel-layers-hiddenWrapper{
            width: 0%;
            height: 0%;
            display: none;
          }
        </style>
        <!--===============================================================================================-->

  </body>
  </html>
