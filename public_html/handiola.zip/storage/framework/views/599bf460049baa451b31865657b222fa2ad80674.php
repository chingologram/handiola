<?php $__env->startSection('wraplogin'); ?>
<div class="site-login">


  <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-50 p-r-50 p-t-77 p-b-30">
          <form class="login100-form" action="<?php echo e(route('logininit')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

					<span class="login100-form-title p-b-55">
            <img src="template/images/br.png" alt="">
					</span>

          <div class="wrap-input100 validate-input m-b-16" data-validate = "Valid email is required: ex@abc.xyz">
          <input class="input100" type="text" name="email" placeholder="Email">
          <span class="focus-input100"></span>
          <span class="symbol-input100">
            <span class="lnr lnr-envelope"></span>
          </span>
          <?php echo $errors->first('email','<span class="help-block">:message</span>'); ?>

        </div>

        <div class="wrap-input100 validate-input m-b-16" data-validate = "Password is required">
          <input class="input100" type="password" name="password" placeholder="Contraseña">
          <span class="focus-input100"></span>
          <span class="symbol-input100">
            <span class="lnr lnr-lock"></span>
          </span>
          <?php echo $errors->first('password','<span class="help-block">:message</span>'); ?>

        </div>

        <div class="contact100-form-checkbox m-l-4">
          <input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
          <label class="label-checkbox100" for="ckb1">
            Recordar
          </label>
        </div>

        <div class="container-login100-form-btn p-t-25">
          <button type="submit" class="login100-form-btn">
            Iniciar Sesión
          </button>
          O
          <button class="login100-form-btn">
            Registrarse
          </button>
        </div>

        <div class="text-center w-full p-t-42 p-b-22">
          <span class="txt1">
            O Iniciar Sesión Con
          </span>
        </div>

        <a href="facebook" class="btn-face m-b-10">
          <i class="fa fa-facebook-official"></i>
          Facebook
        </a>

        <a href="redirectgo" class="btn-google m-b-10">
          <img src="template/login/images/icons/icon-google.png" alt="GOOGLE">
          Google
        </a>

        <div class="text-center w-full p-t-115">
          <span class="txt1">
            No Recuerdas?
          </span>

          <a class="txt1 bo1 hov1" href="#">
            Sign up ahora
          </a>
        </div>
         </form>


			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<style >
  #skel-layers-hiddenWrapper{
    width: 0%;
    height: 0%;
    display: none;
  }
</style>

<?php echo $__env->make('Layouts/_layoutlogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>