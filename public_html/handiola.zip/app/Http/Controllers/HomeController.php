<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{

      public function inicio(){
        if (Auth::check()) {
         return view('Home');
        }else{
        return view('Home');
         }
     }
     public function login(){
       if (Auth::check()) {
        return view('Reserva');
       }else{
           return view('Login');
       }
     }
     public function calcularReserva(){

     }
     public function contacto(){

     }

}
